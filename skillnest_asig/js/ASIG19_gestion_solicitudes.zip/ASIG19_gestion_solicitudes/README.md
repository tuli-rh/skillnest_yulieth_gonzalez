# Gestion de solicitudes

## Resultado ![alt text](<resources/resultado final.png>)



**Autor/a:** Yulieth Gonzalez

**Contacto:** yuliethgonzalez@liceovvh.cl