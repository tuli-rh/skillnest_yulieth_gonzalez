# Entrada a Wikipedia
**autor:** yuliethgonzalez@liceovvh.cl
Yulieth Gonzalez