function darLike1() {
    const spanLike = document.querySelector("#like");
    let cantidad = parseInt(spanLike.innerText);
    spanLike.innerText = cantidad + 1;
    console.log("cantidad");
}

function darLike2() {
    const spanLike = document.querySelector("#like2");
    let cantidad = parseInt(spanLike.innerText);
    spanLike.innerText = cantidad + 1;
    console.log("cantidad");
}

function darLike3() {
    const spanLike = document.querySelector("#like3");
    let cantidad = parseInt(spanLike.innerText);
    spanLike.innerText = cantidad + 1;
    console.log("cantidad");
}