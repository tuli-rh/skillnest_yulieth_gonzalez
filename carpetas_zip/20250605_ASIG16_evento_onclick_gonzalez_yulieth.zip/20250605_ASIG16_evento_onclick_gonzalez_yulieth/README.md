# Evento onclick
**Autor:** yuliethgonzalez@liceovvh.cl
Yulieth Gonzalez