# Barras de navegación 
**Autor:** Yulieth Gonzalez
**Contacto:** yuliethgonzalez@liceovvh.cl

Instrucciones

ASIGNACIÓN PRACTICA (para subir la nota de la ES02)
Replicar las siguientes barras de navegación.
Utilizar colores personalizados, fuente de Google Fonts y textos en español.
Las tres barra de navegación deben estar en el archivo index.html.
Los estilos CSS los debes escribir en español. Utilizar flexbox.
No utilizar IA. Mantener silencio durante la asignación, es individual.