# Diseñando modelo d cajas 
**Autor:** yuliethgonzalez@liceovvh.cl
