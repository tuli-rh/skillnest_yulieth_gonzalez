# Columnas flex
**Autor:** yuliethgonzalez@liceovvh.cl
Yulieth Gonzalez