# Gamesteam

## Resumen de la paleta de colores:

- Colores principales: Azules oscuros (#3F4F64, #2D3948)
- Color de acento: Verde (#86B31E)
- Color de texto principal: Blanco (#FFF)
- Color de enlace: Azul claro (#0BA8E1)